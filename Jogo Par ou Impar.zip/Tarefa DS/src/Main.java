
package jogods;

public class Main {
    public static void main(String[] args){

        JogoDs jogo = new JogoDs();

    }
}
