
package jogods;

import java.util.Random;
import java.util.Scanner;


public class JogoDs {

    String nome1, nome2, par, impar;

    int parOuImpar, val1, val2, resultado, res1 = 0, res2 = 0, round = 0, venceu, tentarNov = 0, tentNov = 0, tentarNov2 = 0, vez = 0, p1, p2, test = 0;

    Scanner in = new Scanner(System.in);
    Random rand = new Random();

    public void pegarNumJogador(){

        tentarNov = 0;

        System.out.print("\n\nUm número de 1 a 5: ");
        val1 = in.nextInt();
        
        if(val1 <= 5 && val1 > 0){
            System.out.println("\n");
            tentarNov = 1;
        }

        else if(val1 > 5){

            System.out.println("\n\nNúmero inválido!");

            do {

                if(tentarNov == 0){
                    System.out.print("\n\n(1 - SIM / 2 - NÃO) Quer tentar novamente? ");
                    tentarNov = in.nextInt();

                    if(tentarNov == 1){
                        pegarNumJogador();
                    }
                    else if(tentarNov == 2){
                        System.exit(0);
                    }
                    else {
                        System.out.print("\nOpção inválida! Tente novamente.");
                    }
                }
                else {
                    System.out.print("");
                    break;
                }

            }while(tentarNov != 1 || tentarNov != 2);
            
        }
    }


    public void pegarNome(){
        System.out.print("\n\n\nQual o seu nome? Nome: ");
        nome1 = in.next();
    }

    public void computador(){
        
        pegarNome();

        do{

            round++;
            System.out.println("\n\n\n\n\nRound: " + round);


            System.out.println("\n\n");

            val2 = rand.nextInt(5);




            System.out.print("\n\nDigite |1| para PAR \nDigite |2| para ÍMPAR");

            System.out.print("\n\nOpção: ");
            parOuImpar = in.nextInt();


            if(test == 0){
                val1 = rand.nextInt(5);
                test = 1;
            }
            else {
                pegarNumJogador();
            }



            if(parOuImpar == 1){
                par = "Par";
                impar = "Ímpar";
                System.out.print(nome1 + " - " + par + ": " + val1 + " vs Computador - " + impar + ": " + val2);
            }
            else {
                par = "Par";
                impar = "Ímpar";
                System.out.print(nome1 + " - " + impar + ": " + val1 + " vs Computador - " + par + ": " + val2);
            }


            

            resultado = val1 + val2;

            System.out.println("\n\n\n\n");


            if(parOuImpar == 1){
                if(resultado % 2 == 0){
                    System.out.println(nome1 + " GANHOU!");
                    res1 = res1 + 1;
                }
                if(resultado % 2 == 1 || resultado % 2 == 0.1){
                    System.out.println("Computador GANHOU!");
                    res2 = res2 + 1;
                }
            }
            else {
                if(resultado % 2 == 0){
                    System.out.println("Computador GANHOU!");
                    res2 = res2 + 1;
                }
                if(resultado % 2 == 1 || resultado % 2 == 0.1){
                    System.out.println(nome1 + " GANHOU!");
                    res1 = res1 + 1;
                }
            }


            System.out.println("\nResultado: " + nome1 + ": " + res1 + " x Computador:" + res2 );



            System.out.println("\n\n\n\n");



            if(res1 == 2){
                System.out.print(nome1 + " Venceu a rodada!");
                venceu = 2;
                System.out.println("\n\nPlacar final: " + nome1 + ": " + res1 + " x Computador:" + res2 + "\n\n");
            }
            if(res2 == 2){
                System.out.print("Computador venceu a rodada!");
                venceu = 2;
                System.out.println("\n\nPlacar final: " + nome1 + ": " + res1 + " x Computador:" + res2 + "\n\n");
            }

        
        }while(venceu != 2);

    }
    






    // Contra o amigo


    public void pegarNomes(){
        System.out.print("\n\n\nNome do 1º player: ");
        nome1 = in.next();

        System.out.print("\n\nNome do 2º player: ");
        nome2 = in.next();
    }

    public void parOuImpar(){

        parOuImpar = 0;

        System.out.print(nome1 + ",\nDigite |1| para PAR \nDigite |2| para ÍMPAR");
        System.out.print("\n\nOpção: ");
        parOuImpar = in.nextInt();

        if(parOuImpar == 1 || parOuImpar == 2){
            System.out.println("");
        }
        else {
            System.out.println("\n\nNúmero inválido! Tente novamente.");
            parOuImpar = 0;
            parOuImpar();
        }

    }

    public void pegarNumJogador1(){

        val1 = 0;

        parOuImpar();

        tentarNov = 0;

        System.out.print("\n\n" + nome1 + ", um número de 1 a 5: ");
        val1 = in.nextInt();
        
        if(val1 <= 5 && val1 > 0){
            System.out.println("\n");
            tentarNov = 1;
        }

        else if(val1 > 5){

            System.out.println("\n\nNúmero inválido!");

            do {

                if(tentarNov == 0){
                    System.out.print("\n\n(1 - SIM / 2 - NÃO) Quer tentar novamente? ");
                    tentarNov = in.nextInt();

                    if(tentarNov == 1){
                        pegarNumJogador();
                    }
                    else if(tentarNov == 2){
                        System.exit(0);
                    }
                    else {
                        System.out.print("\nOpção inválida! Tente novamente.");
                    }
                }
                else {
                    System.out.print("");
                    break;
                }

                System.out.println("\n\n-----" + val1 + "-----\n\n");


            }while(tentarNov != 1 || tentarNov != 2);
            

        }
    }

    public void pegarNumJogador2(){

        val2 = 0;
        tentarNov2 = 0;

        System.out.print(nome2 + ", um número de 1 a 5: ");
        val2 = in.nextInt();
        
        if(val2 <= 5 && val2 > 0){
            System.out.println("\n");
            tentarNov2 = 1;
        }

        else if(val2 > 5){

            System.out.println("\n\nNúmero inválido!");

            do {

                if(tentarNov2 == 0){
                    System.out.print("\n\n(1 - SIM / 2 - NÃO) Quer tentar novamente? ");
                    tentarNov2 = in.nextInt();

                    if(tentarNov2 == 1){
                        pegarNumJogador2();
                    }
                    else if(tentarNov2 == 2){
                        System.exit(0);
                    }
                    else {
                        System.out.print("\nOpção inválida! Tente novamente.");
                    }
                }
                else {
                    System.out.print("");
                    break;
                }

                System.out.println("\n\n-----" + val2 + "-----\n\n");

            }while(tentarNov2 != 1 || tentarNov2 != 2);
            
        }
    }

    public void amigo(){
        
        pegarNomes();

        do{

            round++;
            System.out.println("\n\n\n\n\nRound: " + round + "\n\n");



            if(test == 0){
                parOuImpar();

                val1 = rand.nextInt(5);
                val2 = rand.nextInt(5);
                test = 1;
            }
            else {
                pegarNumJogador1();
                pegarNumJogador2();
            }
            



            resultado = val1 + val2;

            System.out.println("\n\n\n\n");


            System.out.println("[" + nome1 + "] jogou: <" + val1 + "> e [" + nome2 + "] jogou: <" + val2 + ">.");


            if(parOuImpar == 1){
                if(resultado % 2 == 0){
                    System.out.println(nome1 + " GANHOU!");
                    res1 = res1 + 1;
                }
                if(resultado % 2 == 1 || resultado % 2 == 0.1){
                    System.out.println(nome2 + " GANHOU!");
                    res2 = res2 + 1;
                }
            }
            else {
                if(resultado % 2 == 0){
                    System.out.println(nome2 + " GANHOU!");
                    res2 = res2 + 1;
                }
                if(resultado % 2 == 1 || resultado % 2 == 0.1){
                    System.out.println(nome1 + " GANHOU!");
                    res1 = res1 + 1;
                }
            }


            System.out.println("\nResultado: " + nome1 + ": " + res1 + " x " + nome2 + ":" + res2 );



            System.out.println("\n\n\n\n");



            if(res1 == 2){
                System.out.print(nome1 + " Venceu a rodada!");
                venceu = 2;
                System.out.println("\n\nPlacar final: " + nome1 + ": " + res1 + " x " + nome2 + ": " + res2 + "\n\n");
            }
            if(res2 == 2){
                System.out.print(nome2 + " Venceu a rodada!");
                venceu = 2;
                System.out.println("\n\nPlacar final: " + nome1 + ": " + res1 + " x " + nome2 + ": " + res2 + "\n\n");
            }

        
        }while(venceu != 2);

    }

    public JogoDs(){
        System.out.println("\n\n+------------------------------------------+");
        System.out.println("| Olá! Qual tipo de jogo você deseja fazer |?");
        System.out.println("+----------------------------------+-------+");
        System.out.println("| Contra o computador ............ - ... 1 |");
        System.out.println("| Contra um amigo ................ - ... 2 |");
        System.out.println("+------------------------------------------+\n");

        System.out.print("Opção: ");
        int opcaoJogo = in.nextInt();

        switch(opcaoJogo){
            case 1: computador();
            case 2: amigo();
        }
    }

}